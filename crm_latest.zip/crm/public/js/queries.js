var app = angular.module("crm");

app.filter('myDate', function($filter) {    
    var angularDateFilter = $filter('date');
    return function(theDate) {
       return angularDateFilter(theDate, 'dd MMMM @ HH:mm:ss');
    }
});

app.controller("QueriesController", function($scope, $http, $routeParams){
	$scope.cid = $routeParams.cid;
	$scope.qtList = ["Open", "Closed"];
	// $scope.query = {q_type : undefined, q_date : undefined, q_details : undefined, q_solved_date : undefined, q_gap_reason : undefined };
	$scope.editQ = undefined;
	$scope.editIndexQ = undefined;

	$scope.getQueries = function(cid){

		$http({
			method: "GET",
			url : url + "queries/" + cid
		}).then(
		function mySuccess(response){
			$scope.customerwithqueries = response.data[0];
			$scope.prepareQueryGraph();
		},
		function myError(response){
			console.log(response.data);
		}
		);
	}

	$scope.addQuery = function(){
		$scope.query.customer_id = $scope.customerwithqueries.id;
		$http({
			method : 'POST',
			url : url + 'query',
			data : JSON.stringify($scope.query)
		})
		.then(
			function mySuccess(response){
				if($scope.editQ){
					$scope.customerwithqueries.queries.splice($scope.editIndexQ, 1, response.data.newquery);
					alert("Customer query details edited successfully");
				}
				else{
					$scope.customerwithqueries.queries.push(response.data.newquery);	
					alert("Customer query details added successfully");
				}			
				$scope.prepareQueryGraph();
				window.scrollTo(0,0);
			},
			function myError(response){
				alert("Operation failed...Please try again");
			}
		);
	}

	$scope.resetQuery = function(){
		$scope.editQ = undefined;
		$scope.editIndexQ = undefined;
		$scope.query = undefined;
		document.getElementById('submitQ').disabled = true;
	}

	$scope.editQuery = function(qid){
		$scope.selected = qid;
		angular.forEach($scope.customerwithqueries.queries, function(q, index){
			if(q.id == qid){
				$scope.query = angular.copy(q);
				$scope.query.q_date = new Date(q.q_date);
				$scope.query.q_solved_date = q.q_solved_date ? new Date(q.q_solved_date) : null;
				$scope.editIndexQ = index;
				return;
			}
		});
		$scope.editQ = true;
	}

	$scope.prepareQueryGraph = function(){

		var opened = 0;
 		var closed = 0;

 		for(var i = $scope.customerwithqueries.queries.length - 1; i >= 0; i--) {
 			if($scope.customerwithqueries.queries[i].q_type === 'Open'){
 				opened += 1;
 			}
 			else{
 				closed += 1;
 			}
 		}
 		
		$(document).ready(function() {  
            var chart = {
               type: 'column'
            };
            var title = {
            	text : ""
            };
            var xAxis = {
               categories: ['Open','Closed'],
               crosshair: true
            };
            var tooltip = {
               headerFormat: '<span>{point.key}</span><table>',
               pointFormat: '<tr><td style = "padding:0">{series.name}: </td>' +
                  '<td style = "padding:0"><b>{point.y}</b></td></tr>',
               footerFormat: '</table>',
               shared: true,
               useHTML: true
            };
            var series= [
               {
               	  showInLegend : false,
                  name: 'Query',
                  data: [opened, closed]
               }
            ];     
         
            var json = {};   
            json.chart = chart;
            json.title = title;
            json.tooltip = tooltip;
            json.xAxis = xAxis;
            json.series = series;
            $('#qg').highcharts(json);
  
         });
	}


	$scope.getQueries($scope.cid);

});
/*var app = angular.module("myApp");
app.controller("QueriesController", function($scope, $http, $routeParams){
	$scope.qflag = true;
	$scope.pid = $routeParams.pid;
	$scope.showModal = false;
	$scope.qmaster = { q_date:"", name:"", q_details:"", solved:"", reasons: "" };
	$scope.editoradd = false;

    $scope.addNewQuery = function(){
    	$scope.query = angular.copy($scope.qmaster);
        $scope.showModal = !$scope.showModal;
        $scope.editoradd = false;
    };

    $scope.resetQuery = function(){
    	$scope.user = angular.copy($scope.qmaster);
    }

	$scope.editQuery = function(i){
    	$scope.showModal = true;	

    	var whatIndex = null;
		angular.forEach($scope.profiles, function(cb, index) {
		  if (cb.id === i) {
		     whatIndex = index;
		  }
		});

		var query = $scope.queries[whatIndex];
		$scope.query = angular.copy($scope.qmaster);
		$scope.query.id = query.id;
		$scope.query.q_date = query.q_date;
		$scope.query.profile_id = query.profile_id;
		$scope.query.q_solved_date = query.q_solved_date;
		$scope.query.q_details = query.q_details;
		$scope.query.more_reasons = query.more_reasons;
		$scope.query.created_at = query.created_at;
    	$scope.query.updated_at = query.updated_at;
    	$scope.editoradd = true;
    }


    $scope.submitQuery = function(){
    	//if(validate()){
    		document.getElementById("spinner").style.display = "block";
    		console.log($scope.query);
    		$scope.query.profile_id = $scope.pid;
    		console.log($scope.query);
			$http({
		        method : "POST",
		        url : url + "queries",
		        data : JSON.stringify($scope.query)
		    }).then(function mySuccess(response) {
		    	if(response.data.saved){
		    		alert("Query added successfully");
			    	if($scope.editoradd){
			    		var whatIndex = null;
						angular.forEach($scope.queries, function(cb, index) {
						  if (cb.id === $scope.query.id) {
						     whatIndex = index;
						  }
						});
						$scope.queries.splice(whatIndex, 1, response.data.newobject);
			    	}
			    	else{
			    		if(!$scope.flag){
			    			$scope.flag = true;
			    			$scope.queries.push(response.data.newobject);
			    		}
			    		else{
			    			$scope.queries.splice(0, 0, response.data.newobject);	
			    		}
			    	}
		    	}
		    	else{
		    		alert( "Unable to add query");
		    	}
		    	$scope.showModal = false;
		        document.getElementById("spinner").style.display = "none";
		    }, function myError(response) {
		    	$scope.showModal = false;
		        document.getElementById("spinner").style.display = "none";
		    });    		
    	//}
    }


	//Fetch list of queries from database - start 
	document.getElementById("spinner").style.display = "block";
	$http({
        method : "GET",
        url : url + "queries/" + $scope.pid
    }).then(function mySuccess(response) {
    	if(response.data.length > 0){
    		$scope.qflag = true;
        	$scope.queries = response.data;
        	console.log($scope.queries);
    	}
    	else{
    		$scope.qflag = false;
    	}
        document.getElementById("spinner").style.display = "none";
    }, function myError(response) {
        $scope.qflag = false;
        document.getElementById("spinner").style.display = "none";
    });
    //Fetch list of queries from database - end


    $scope.deleteQuery = function(id) {
    	document.getElementById("spinner").style.display = "block";
    	$http({
	        method : "GET",
	        url : url + "queries/delete/" + id
	    }).then(function mySuccess(response) {
	    	console.log(response.data);
	        if(response.data == 1){
	        	var whatIndex = null;
				angular.forEach($scope.queries, function(cb, index) {
				  if (cb.id === id) {
				     whatIndex = index;
				  }
				});
                $scope.queries.splice(whatIndex, 1);
                window.scrollTo(0,0);
                alert("Query deleted successfully");
                if($scope.queries.length == 0){
                	$scope.qflag = false;
                }
            }
            else{
            	alert( "Unable to delete query1");
            }
	        document.getElementById("spinner").style.display = "none";
	    }, function myError(response) {
	    	alert( "Unable to delete query");
	        document.getElementById("spinner").style.display = "none";
	    });
    }


});

app.directive('qmodal', function () {
    return {
    	templateUrl : "templates/addquery.html",
	    restrict: 'E',
	    transclude: true,
	    replace:true,
	    scope:true,
	    link: function postLink(scope, element, attrs) {

	          scope.$watch(attrs.visible, function(value){
	          if(value == true)
	            $(element).modal('show');
	          else
	            $(element).modal('hide');
	        });

	        $(element).on('shown.bs.qmodal', function(){
	          scope.$apply(function(){
	            scope.$parent[attrs.visible] = true;
	          });
	        });

	        $(element).on('hidden.bs.qmodal', function(){
	          scope.$apply(function(){
	            scope.$parent[attrs.visible] = false;
	          });
	        });
	    }
	};
});*/