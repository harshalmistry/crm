var app = angular.module("crm");
app.controller("ReviewsController", function($scope, $http, $routeParams){
	$scope.cid = $routeParams.cid;
	$scope.editR = false;

	$scope.getReviews = function(){

		$http({
			method : 'GET',
			url : url + 'reviews/' + $scope.cid
		})
		.then(
			function mySuccess(response){
				$scope.customerwithreviews = response.data[0];
			},
			function myError(response){
				alert("Operation failed...Please try again");
			}
		);	
	}

	$scope.getReviews();

	$scope.editReview = function(r){
		$scope.selected = r.id;
		$scope.review = angular.copy(r);
		$scope.editR = true;
	}

	$scope.aeReview = function(){
		$scope.review.customer_id = $scope.cid;
		$http({
			method : 'POST',
			url : url + 'review',
			data : JSON.stringify($scope.review)
		})
		.then(
			function mySuccess(response){
				if(response.data.saved){
					if($scope.editR){
						alert("Customer portfolio details edited successfully");
						let tempIndex = undefined;
						angular.forEach($scope.customerwithreviews.reviews, function(r, index){
							if(r.id == response.data.newreview.id){
								tempIndex = index;
							}
						});
						$scope.customerwithreviews.reviews.splice(tempIndex, 1, response.data.newreview);
						$scope.editR = false;
					}
					else{
						alert("Customer portfolio details added successfully");
						$scope.customerwithreviews.reviews.unshift(response.data.newreview);
					}	
					document.getElementById("reviewForm").reset();				
				}
				else{
					alert("Operation failed...Please try again");	
				}
			},
			function myError(response){
				alert("Operation failed...Please try again");
			}
		);
	};

});
