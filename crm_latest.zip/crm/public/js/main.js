var app = angular.module("crm", ["ngRoute", "ui.bootstrap"]);
var url = "http://localhost:8000/crm/"
app
    .config(function($routeProvider) {
        $routeProvider
        .when("/meetings",{
            templateUrl : "templates/meetings.html",
            controller : "MeetingsController"
        })
        .when("/customers",{
            templateUrl : "templates/customers.html",
            controller : "CustomersController"
        })
        .when("/", {
            templateUrl : "templates/index.html",
            controller : "IndexController"
        })
        .when("/queries/:cid", {
            templateUrl : "templates/queries.html",
            controller : "QueriesController"
        })
        .when("/portfolio/:cid", {
            templateUrl : "templates/reviews.html",
            controller : "ReviewsController"
        })
        .when("/followup/:cid", {
            templateUrl : "templates/followups.html",
            controller : "FollowupsController"
        })
        .when("/transactions/:cid", {
            templateUrl : "templates/transactions.html",
            controller : "TransactionsController"
        });
    })
    .controller("IndexController", function($scope, $http){
        $scope.index = function(){
            $scope.meetings();
            $scope.customers();
        }

        /* Customers start */
        $scope.customers = function(){
            $http({
                method : 'GET',
                url : url + 'customers'
            }).then(function mySuccess(response){
                if(response.data.length > 0){
                    $scope.customers = response.data;
                    $scope.prepareCustomerGraph();
                }
                else{
                    console.log("Dashboard - No customer's data available in database");
                }
            },
            function myError(response){
                console.log("Dashboard - getCustomers failed");
            });
        }

        $scope.prepareCustomerGraph = function(){
            Highcharts.setOptions({ colors: ['#6b90b7', '##081019'] });
            var investors = 0; var prospects = 0;
            var total = $scope.customers.length;

            for(var i = $scope.customers.length - 1; i >= 0; i--) {
                if($scope.customers[i].type === 'I'){
                    investors += 1;
                }
            }
            prospects = total - investors;
            investors = (investors/total)*100;
            prospects = (prospects/total)*100;
            $scope.totalCustomers = total;
            var chart = {};
            var title = {   text: '' };
            var tooltip = { pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>' };
            var plotOptions = {
               pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b> - {point.percentage:.1f} %',
                        style: {
                            color: (Highcharts.theme && Highcharts.theme.contrastTextColor)||
                            'black'
                        }
                    }
                }
            };
            var series = [{
               type: 'pie',
               name: 'Customer',
               data: [['Investor', investors], ['Prospect', prospects]]
            }];
            var credits = { enabled: false  };
            var json = {};   
            json.chart = chart; 
            json.title = title;     
            json.tooltip = tooltip;  
            json.series = series;
            json.credits = credits;
            json.plotOptions = plotOptions;
            $('#customergraph').highcharts(json);  
        }

        /* Customers end */


        /* Meetings start */
        $scope.meetings = function(){
            $http({
                method : 'GET',
                url : url + 'meetings'
            })
            .then(function mySuccess(response){
                $scope.meetings = response.data;
                $scope.prepareMeetingsGraph();
            }, 
            function myError(response){
                console.log("Unable to fetch meetings data " + response);
            });
        }

        $scope.prepareMeetingsGraph = function(){
            Highcharts.setOptions({
                colors: ['#6b90b7']
            });
            var chart = {   type: 'bar' };
            var title = {   text: ''    };
            var xAxis = {
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
                title: {    text: null  }
            };
            var yAxis = {   
                min: 0,
                title: {    text: 'Meetings'    },
                labels: {   overflow: 'justify' }
            };
            var plotOptions = {
                bar: {  dataLabels: {   enabled: true   }   }
            };
            var credits = { enabled: false  };
            var mnos = [];
            var totalMeetings = 0;
            for (var i = 0; i < $scope.meetings.length; i++) {
                totalMeetings += $scope.meetings[i].nos;
                mnos.push($scope.meetings[i].nos);
            }
            var series = [{ name: 'Total meetings - ' + totalMeetings, data: mnos}];
            var json = {};   
            json.chart = chart; 
            json.title = title;   
            json.xAxis = xAxis;
            json.yAxis = yAxis;  
            json.series = series;
            json.plotOptions = plotOptions;
            json.credits = credits;
            $('#meetingsgraph').highcharts(json);
        }
        /* Meetings end */

        $scope.index();
    })