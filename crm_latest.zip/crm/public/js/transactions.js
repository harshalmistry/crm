var app = angular.module("crm");
app.controller("TransactionsController", function($scope, $http, $routeParams){
	$scope.cid = $routeParams.cid;
	$scope.itList = ["LumSum", "SIP", "SWP", "STP"];
	$scope.editT = false;

	$scope.getTransactions = function(){
		$http({
			method : 'GET',
			url : url + 'transactions/' + $scope.cid
		})
		.then(
			function mySuccess(response){
				$scope.customerwithtransactions = response.data[0];
			},
			function myError(response){
				alert("Operation failed...Please try again");
			}
		);	
	}

	$scope.getTransactions();

	$scope.editTransaction = function(t){
		$scope.selected = t.id;
		$scope.transaction = angular.copy(t);
		$scope.editT = true;
	}

	$scope.resetTransactionForm = function(){
		$scope.editT = false;
		$scope.transaction.t_date = undefined;
		$scope.transaction.scheme_name = undefined;
		$scope.transaction.investment_type = undefined;
		$scope.transaction.t_amount = undefined;
		$scope.transaction.kyc_status = 'no';
		$scope.transaction.next_t_date = undefined;
		$scope.transaction.courier_done = 'no';
	}

	$scope.aeTransaction = function(){
		$scope.transaction.customer_id = $scope.cid;
		$http({
			method : 'POST',
			url : url + 'transaction',
			data : JSON.stringify($scope.transaction)
		})
		.then(
			function mySuccess(response){
				if(response.data.saved){
					console.log(response.data);
					if($scope.editT){
						alert("Customer transaction details edited successfully");
						let tempIndex = undefined;
						angular.forEach($scope.customerwithtransactions.transactions, function(f, index){
							if(f.id == response.data.newtransaction.id){
								tempIndex = index;
							}
						});
						$scope.customerwithtransactions.transactions.splice(tempIndex, 1, response.data.newtransaction);
						$scope.editT = false;
					}
					else{
						alert("Customer transaction details added successfully");
						$scope.customerwithtransactions.transactions.unshift(response.data.newtransaction);
					}	
				}
				else{
					alert("Operation failed...Please try again");	
				}
			},
			function myError(response){
				alert("Operation failed...Please try again");
			}
		);
	}
});